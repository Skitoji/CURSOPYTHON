#Tuplas muy similares a las listas
#No pueden modificarse
#Se utilizan parentesis en lugar de []

lista = ["Rodrigo", "Juan"] #Constantemente agregando informacion
tupla = ("Rodrigo", "Juan")

videojuegos = []
#Nombre, Genero, Año
videojuegos.append( ("Final Fantasy 7", "JRPG", 1997) )
videojuegos.append( ("Outer Wilds", "Aventura", 2019) )
print(videojuegos)