def saludar_y_sumar(nombre, num1, num2=0):
    print("Saludos", nombre)
    print("Resultado de la suma", num1+num2)
    
saludar_y_sumar("Rodrigo", 10, 5)
saludar_y_sumar("Juan", 2)
saludar_y_sumar("Pedro", 800, 5000)