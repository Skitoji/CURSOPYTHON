print("Escribe tu nombre:")
nombre = input()
#print("Escribe tu edad")
#edad = int(input())

#elif
#Operadores Lógicos
#and (y)  / or (o)
#and: Todas las expresiones sean True
#or: Con que una de las expresiones sea True
#> <    >=   <=

if nombre == "Rodrigo" or nombre == "Santiago":
    print("Me gusta tu nombre")
else:
    print("Que nombre tan extraño")