#Lógico Boolean Booleano Bool
#Verdadero / Falso: True / False
#dato = 5 < 5
#> <  ==

print("Ingresa tu nombre")
nombre = input()

if nombre == "Rodrigo":
    print("Bienvenido Rodrigo")
else:
    print("Que nombre tan extraño")